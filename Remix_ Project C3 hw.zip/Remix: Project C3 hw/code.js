var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4c3ae48d-938d-4c2a-9370-86de38b232bb"],"propsByKey":{"4c3ae48d-938d-4c2a-9370-86de38b232bb":{"name":"cup","sourceUrl":null,"frameSize":{"x":170,"y":398},"frameCount":1,"looping":true,"frameDelay":12,"version":"LdnXs4eu2UnWxwZQ2joj.FX0xWwHztxM","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":170,"y":398},"rootRelativePath":"assets/4c3ae48d-938d-4c2a-9370-86de38b232bb.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the player sofia
var sofia = createSprite(25,25,18,18 );
sofia.shapeColor = "pink";

//creating the maze walls (wall1 - wall2)
  var wall1 = createSprite(100,100,20,200);
  var wall2 = createSprite(170,100,20,70);
  var wall3 = createSprite(300,254,20,330);
  var wall4 = createSprite(140,200,100,10);
  var wall5 = createSprite(250,100,135,10);
  var wall6 = createSprite(250,300,135,10);
  var wall7 = createSprite(100,340,20,150);
  

  
//create cup
var cup = createSprite(350,350,40,40);
  cup.shapeColor = "gold";
 function draw() {
   background("black");
   createEdgeSprites();
  sofia.bounceOff(edges);




if(keyDown("UP_ARROW")){
sofia.velocityX = 0;
sofia.velocityY = -4;
}
if(keyDown("DOWN_ARROW")){
sofia.velocityY = 4;
sofia.velocityX = 0;
}
if(keyDown("RIGHT_ARROW")){
  sofia.velocityY = 0;
  sofia.velocityX = 4;
}
if(keyDown("LEFT_ARROW")) {
  sofia.velocityX = -4;
  sofia.velocityY = 0;
}


  



sofia.bounceOff(wall1);
sofia.bounceOff(wall2);
sofia.bounceOff(wall3);
sofia.bounceOff(wall4);
sofia.bounceOff(wall5);
sofia.bounceOff(wall6);
sofia.bounceOff(wall7);

if( sofia.collide(cup)) { 
  background("white");


textSize(40);
  stroke("red");
  text("You Win", 200,200);
}
  
drawSprites();
}






















// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
